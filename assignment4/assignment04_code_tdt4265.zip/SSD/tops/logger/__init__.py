from .logger import (
    log, add_dict, add_scalar,
    epoch, global_step, step, step_epoch, finish, read_logs)